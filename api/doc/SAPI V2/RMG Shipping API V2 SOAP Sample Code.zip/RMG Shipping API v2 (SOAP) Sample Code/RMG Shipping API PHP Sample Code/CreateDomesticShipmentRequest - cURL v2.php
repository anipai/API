<?php
/*------------------------------------------------------------------------------------------------------------------	*/
/* This code has been written as a sample to demonstrate how the API call can be  	*/
/* made using PHP cURL. The code also shows the auto generation of 		*/
/* password digest, encoded nonce and time when these values are created       	*/
/* can be calculated, to populate the WS-security header of the SAPI SOAP service. 	*/
/* The security header for the SAPI service needs to provide,                     		*/
/* Username as - <wsse:Username>YOURUSENAME</wsse:Username> 		*/
/* where YOURUSENAME is the username provided by RMG 			*/
/* Password as - <wsse:Password Type="http://d...content-available-to-author-only...n.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest">PASSWORDDIGEST</wsse:Password> */
/* where PASSWORDDIGEST is calculated as shown in the code below 		*/
/* Nonce as - <wsse:Nonce EncodingType="http://d...content-available-to-author-only...n.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary">ENCODEDNONCE</wsse:Nonce> 	*/
/* where ENCODEDNONCE is shown in the code below 				*/
/* Creation date - <wsu:Created>CREATIONDATE</wsu:Created> 			*/
/* where CREATIONDATE is shown in the code below 				*/
/* 									*/
/* To make a successful API call by using the code below, one must: 			*/
/*          a) Provide the right username            				              	*/
/*          a) Change the password to your password    				*/
/*-------------------------------------------------------------------------------------------------------------------*/

$apiURL = "https://api.royalmail.net/shipping/v2";
$dateTime = date('Y-m-d\TH:i:s');
$applicationId = "xxx";
$transactionId = "xx";
$shippingDate = gmdate('Y-m-d');
$shipmentType = "Delivery";
$serviceOccurrence = "x";
$serviceType = "x";
$serviceCode = "xx";
$serviceFormat = "x";
$recipientContactName = "Tom Smith";
$recipientAddressLine1 = "3 Bowerman Close";
$postTown = "London";
$postcode = "OX5 1TP";
$countryCode = "GB";
$noOfItems = "1";
$unitOfMeasure = "g";
$weightValue = "100";
$sendersReference = "123ABC";

/* Change the values below to the ClientID and Secret values associated with the application you
 * registered on the API Developer Portal
 */
$clientId = "xxx";
$clientSecret = "xxx";

/* The value below should be changed to your actual username and password.  If you store the password
 * as hashed in your database, you will need to change the code below to remove hashing
 */
$username = "xxx";
$password = "xxx";


/* CREATIONDATE - The timestamp. The computer must be on correct time or the server you are
* connecting may reject the password digest for security.
*/
$creationDate = gmdate('Y-m-d\TH:i:s\Z');

/* NONCE - A random word.
* The use of rand() may repeat the word if the server is very loaded.
*/
$nonce = mt_rand();

/* PASSWORDDIGEST This is the way to create the password digest. As per OASIS standard
* digest = base64_encode(Sha1(nonce + creationdate + Sha1(password)))
* Note that we use a Sha1(password) instead of the plain password above
*/
$nonce_date_pwd = $nonce.$creationDate.base64_encode(sha1($password, TRUE));
$passwordDigest = base64_encode(sha1($nonce_date_pwd, TRUE));

/* ENCODEDNONCE - Now encode the nonce for security header */
$encodedNonce = base64_encode($nonce);

/* Print all WS-Security values for debugging
 * echo 'nonce: ' . $nonce . PHP_EOL;
 * echo 'password digest: ' . $passwordDigest . PHP_EOL;
 * echo 'encoded nonce: ' . $encodedNonce . PHP_EOL;
 * echo 'creation date: ' . $creationDate . PHP_EOL;
 */

$curl = curl_init();

/* The commented code below is provided for customers to adapt to handle the client side security
 * implementation for the API
 *
 * PHP code to validate the certificate returned from APIm
 * CURLOPT_SSL_VERIFYHOST can be set to the following integer values:
 * 0: Dont check the common name (CN) attribute
 * 1: Check that the common name attribute at least exists
 * 2: Check that the common name exists and that it matches the host name of the server
 */
// curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);
// curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
// curl_setopt($curl, CURLOPT_CAINFO, getcwd() . "\(path)\api.royalmail.net.crt");

curl_setopt_array($curl, array(
  CURLOPT_URL => $apiURL,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
	CURLOPT_POSTFIELDS => "<soapenv:Envelope xmlns:oas=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:v1=\"http://www.royalmailgroup.com/integration/core/V1\" xmlns:v2=\"http://www.royalmailgroup.com/api/ship/V2\">\r\n   <soapenv:Header>\r\n      <wsse:Security xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">\r\n         <wsse:UsernameToken>\r\n            <wsse:Username>$username</wsse:Username>\r\n            <wsse:Password Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest\">$passwordDigest</wsse:Password>\r\n            <wsse:Nonce EncodingType=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary\">$encodedNonce</wsse:Nonce>\r\n            <wsu:Created>$creationDate</wsu:Created>\r\n         </wsse:UsernameToken>\r\n      </wsse:Security>\r\n   </soapenv:Header>\r\n   <soapenv:Body>\r\n      <v2:createShipmentRequest>\r\n         <v2:integrationHeader>\r\n            <v1:dateTime>$dateTime</v1:dateTime>\r\n            <v1:version>2</v1:version>\r\n            <v1:identification>\r\n               <v1:applicationId>$applicationId</v1:applicationId>\r\n               <v1:transactionId>$transactionId</v1:transactionId>\r\n            </v1:identification>\r\n         </v2:integrationHeader>\r\n         <v2:requestedShipment>\r\n            <v2:shipmentType>\r\n               <code>$shipmentType</code>\r\n            </v2:shipmentType>\r\n            <v2:serviceOccurrence>$serviceOccurrence</v2:serviceOccurrence>\r\n            <v2:serviceType>\r\n               <code>$serviceType</code>\r\n            </v2:serviceType>\r\n            <v2:serviceOffering>\r\n               <serviceOfferingCode>\r\n                  <code>$serviceCode</code>\r\n               </serviceOfferingCode>\r\n            </v2:serviceOffering>\r\n            <v2:serviceFormat>\r\n               <serviceFormatCode>\r\n                  <code>$serviceFormat</code>\r\n               </serviceFormatCode>\r\n            </v2:serviceFormat>\r\n            <v2:shippingDate>$shippingDate</v2:shippingDate>\r\n            <v2:recipientContact>\r\n               <v2:name>$recipientContactName</v2:name>\r\n            </v2:recipientContact>\r\n            <v2:recipientAddress>\r\n               <addressLine1>$recipientAddressLine1</addressLine1>\r\n               <postTown>$postTown</postTown>\r\n               <postcode>$postcode</postcode>\r\n               <country>\r\n                  <countryCode>\r\n                     <code>$countryCode</code>\r\n                  </countryCode>\r\n               </country>\r\n            </v2:recipientAddress>\r\n            <v2:items>\r\n               <v2:item>\r\n                  <v2:numberOfItems>$noOfItems</v2:numberOfItems>\r\n                  <v2:weight>\r\n                     <unitOfMeasure>\r\n                        <unitOfMeasureCode>\r\n                           <code>$unitOfMeasure</code>\r\n                        </unitOfMeasureCode>\r\n                     </unitOfMeasure>\r\n                     <value>$weightValue</value>\r\n                  </v2:weight>\r\n               </v2:item>\r\n            </v2:items>\r\n            <v2:senderReference>$sendersReference</v2:senderReference>\r\n         </v2:requestedShipment>\r\n      </v2:createShipmentRequest>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>",
  CURLOPT_HTTPHEADER => array(
    "accept: application/soap+xml",
    "accept-encoding: gzip,deflate",
    "connection: keep-alive",
    "content-type: text/xml",
    "host: api.royalmail.net",
    "soapaction: \"createShipment\"",
    "x-ibm-client-id: $clientId",
    "x-ibm-client-secret: $clientSecret"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  echo $response;
}
?>

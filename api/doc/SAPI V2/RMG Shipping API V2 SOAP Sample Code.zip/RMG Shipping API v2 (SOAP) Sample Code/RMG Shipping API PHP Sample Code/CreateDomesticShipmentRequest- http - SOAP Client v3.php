<?php
/*-------------------------------------------------------------------------------------------------------------------*/
/* This code has been written as a sample to demonstrate how the API call can be  	*/
/* made using the PHP SOAP client. The code also shows the auto generation of 	*/
/* password digest, encoded nonce and time when these values are created      	*/
/* can be calculated, to populate the WS-security header of the SAPI SOAP service.	*/
/* The security header for the SAPI service needs to provide,                     		*/
/* Username as - <wsse:Username>YOURUSENAME</wsse:Username>            		*/
/*                 where YOURUSENAME is the username provided by RMG               		*/
/* Password as - <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest">PASSWORDDIGEST</wsse:Password> 			*/
/*                where PASSWORDDIGEST is calculated as shown in the code below    	*/
/* Nonce as - <wsse:Nonce EncodingType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary">ENCODEDNONCE</wsse:Nonce>   			*/
/*                where ENCODEDNONCE is shown in the code below                    		*/
/* Creation date - <wsu:Created>CREATIONDATE</wsu:Created>                         	*/
/*                where CREATIONDATE is shown in the code below                   		*/
/*                                                                                 					*/
/* To make a successful API call by using the code below, one must: 			*/
/*          a) Provide the right username            				              	*/
/*          a) Change the password to your password    				*/
/*-------------------------------------------------------------------------------------------------------------------*/

$apiURL = "https://api.royalmail.net/shipping/v2";
$dateTime = date('Y-m-d\TH:i:s');
$applicationId = "xxx";
$transactionId = "xx";
$shippingDate = gmdate('Y-m-d');
$shipmentType = "Delivery";
$serviceOccurrence = "1";
$serviceType = "1";
$serviceCode = "xx";
$serviceFormat = "x";
$recipientName = "Tom";
$recipientComplementaryName = "";
$recipientAddressLine1 = "3 Bowerman Close";
$recipientAddressLine2 = "";
$postTown = "London";
$postcode = "EC1 4GW";
$countryCode = "GB";
$noOfItems = "x";
$unitOfMeasure = "xx";
$weightValue = "xxx";
$sendersReference = "123ABC";

/* Change the values below to the ClientID and Secret values associated with the application you
 * registered on the API Developer Portal
 */
$clientId = "xxx";
$clientSecret = "xxx";

/* The values below should be changed to your actual username and password. If you store the password
 * as hashed in your database, you will need to change the code below to remove hashing
 */
$username = "xxx";
$password = "xxx";

/* CREATIONDATE - The timestamp. The computer must be on correct time or the server you are
 * connecting may reject the password digest for security.
 */
$creationDate = gmdate('Y-m-d\TH:i:s\Z');

/* NONCE - A random word.
 * The use of rand() may repeat the word if the server is very loaded.
 */
$nonce = mt_rand();

/* PASSWORDDIGEST This is the way to create the password digest. As per OASIS standard
 * digest = base64_encode(Sha1(nonce + creationdate + Sha1(password)))
 * Note that we use a Sha1(password) instead of the plain password above
 */
$nonce_date_pwd = $nonce.$creationDate.base64_encode(sha1($password, TRUE));
$passwordDigest = base64_encode(sha1($nonce_date_pwd, TRUE));

/* ENCODEDNONCE - Now encode the nonce for security header */
$encodedNonce = base64_encode($nonce);

/* Print all WS-Security values for debugging
echo 'nonce: ' . $nonce . PHP_EOL;
echo 'password digest: ' . $passwordDigest . PHP_EOL;
echo 'encoded nonce: ' . $encodedNonce . PHP_EOL;
echo 'creation date: ' . $creationDate . PHP_EOL;
*/

$options = array(
    'uri'=>'http://schemas.xmlsoap.org/soap/envelope/',
    'style'=>SOAP_RPC,
    'use'=>SOAP_ENCODED,
    'soap_version'=>SOAP_1_1,
    'connection_timeout'=>15,
    'trace'=>true,
    'encoding'=>'UTF-8',
    'exceptions'=>true,
	'location' => $apiURL,
	'stream_context' => stream_context_create(
		[
			'http' =>
				[
					'header'=> implode(
						"\r\n",
						[
							'Accept: application/soap+xml',
							'X-IBM-Client-Id: ' . $clientId,
							'X-IBM-Client-Secret: ' . $clientSecret,
						]
					),
				],
		]
	)
);

$client = new SoapClient("https://api.royalmail.net/shipping/v2?wsdl", $options);

$HeaderObjectXML  = '<wsse:Security xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd"
                      xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">
           <wsse:UsernameToken>
              <wsse:Username>'.$username.'</wsse:Username>
              <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest">'.$passwordDigest.'</wsse:Password>
              <wsse:Nonce EncodingType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary">'.$encodedNonce.'</wsse:Nonce>
              <wsu:Created>'.$creationDate.'</wsu:Created>
           </wsse:UsernameToken>
       </wsse:Security>';

 //Then create a new soap Var for this and push the header into soap
$HeaderObject = new SoapVar( $HeaderObjectXML, XSD_ANYXML );

//Then finally push the header inot the SOAP header element
$header = new SoapHeader( 'http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd', 'Security', $HeaderObject );
$client->__setSoapHeaders($header);

// Build the API request message
 $request = Array(
    'integrationHeader' => array(
        'dateTime' => $dateTime,
        'version' => '2',
        'identification' => array(
            'applicationId' => $applicationId,
            'transactionId' => $transactionId
        ),
    ),
    'requestedShipment' => array(
        'shipmentType' => array(
            'code' => $shipmentType
        ),
    'serviceOccurrence' => $serviceOccurrence,
        'serviceType' => array(
            'code' => $serviceType
        ),
        'serviceOffering' => array(
            'serviceOfferingCode' => array(
                'code' => $serviceCode
            )
        ),
        'serviceFormat' => array(
            'serviceFormatCode' => array(
                'code' => $serviceFormat
            )
        ),
        'shippingDate' => $shippingDate,
        'recipientContact' => array(
            'name' => $recipientName,
            'complementaryName' => $recipientComplementaryName
        ),
        'recipientAddress' => array(
            'addressLine1' => $recipientAddressLine1,
            'addressLine2' => $recipientAddressLine2,
            'postTown' => $postTown,
            'postcode' => $postcode,
			'country'  => array(
				'countryCode' => array(
					'code' => $countryCode
					)
			)
        ),
        'items' => array(
            'item' => array(
                'numberOfItems' => $noOfItems,
                'weight' => array(
                    'unitOfMeasure' => array(
                        'unitOfMeasureCode' => array(
                            'code' => $unitOfMeasure
                        )
                    ),
                    'value' => $weightValue
                )
            )
        ),
		'senderReference' => $sendersReference
    )
);

// Make the Shipping API call
try
{
    $response = $client->__soapCall('createShipment', array($request), array('soapaction' => 'https://api.royalmail.com/shipping/v2') );

	// Echo/print the result obtained from the above SOAP call
    echo "<pre>".print_r($response, true)."</pre>";
}
catch (Exception $e)
{
    // Catch the error message and echo the last request for debug
    echo $e->getMessage();
    echo " REQUEST:\n" . $client->__getLastRequest() . "\n";
    die;
}
?>

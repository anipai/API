﻿//---------------------------------------------------------------------------------*/
// This code has been written as a sample to demonstrate how the password digest   */
// can be calculated, to populate the WS-security header of the SAPI SOAP service. */
// The security header for the SAPI service needs to provide,                      */
//  Username as - <wsse:Username>YOURUSENAME</wsse:Username>                       */
//                 where YOURUSENAME is the username provided by RMG               */
//  Password as - <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest">PASSWORDDIGEST</wsse:Password> */
//                where PASSWORDDIGEST is calculated as shown in the code below    */
//  Nonce as - <wsse:Nonce EncodingType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary">ENCODEDNONCE</wsse:Nonce>   */
//                where ENCODEDNONCE is shown in the code below                    */
// Creation date - <wsu:Created>CREATIONDATE</wsu:Created>                         */
//                where CREATIONDATE is shown in the code below                    */
//                                                                                 */
//To Use code below, one must a) Change the password to your password              */
//                                                                                 */
//                                                                                 */
//                                                                                 */
//       Author:    RMG                                                            */
//       Version:   1.0.1                                                          */
//       Date:      19/04/2016                                                     */
//                                                                                 */
//                                                                                 */
//                                                                                 */
//                                                                                 */
//---------------------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace PasswordDigest
{
    public class DigestGenerator
    {
        // The value below should be changed to your password.  If you store the password  */
        // as hashed in your database, you will need to change the code below to remove hashing */
        private const string PASSWORD_STRING = @"Password1*";
 
        static void Main(string[] args)
        {
            GeneratePasswordDigest();
            Console.WriteLine("press any key to quit...");
            Console.ReadKey();
        }

        private static byte[] GetSHA1(string input)
        {
            return SHA1Managed.Create().ComputeHash(Encoding.Default.GetBytes(input));
        }
      
        private static void GeneratePasswordDigest()
        {
        // CREATIONDATE - The timestamp. The computer must be on correct time or the server you are
        // connecting may reject the password digest for security.
 			string creationDate;
			creationDate = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ");
 
        //declare a nonce (number used once) and assign it a random positive integer value.
            string nonce;
            nonce = (new Random().Next(0, int.MaxValue)).ToString();

         // PASSWORDDIGEST This is the way to create the password digest. As per OASIS standard
         // digest = base64_encode(Sha1(nonce + creationdate + Sha1(password)))
		 // Note that we use a Sha1(password) instead of the plain password above
            string nonceDataPassword = string.Concat(nonce, creationDate,Convert.ToBase64String(GetSHA1(PASSWORD_STRING)));
            string passwordDigest = Convert.ToBase64String(GetSHA1(nonceDataPassword));

         // ENCODEDNONCE - Now encode the nonce for security header */
            string encodedNonce;
            encodedNonce = Convert.ToBase64String(Encoding.Default.GetBytes(nonce));

         // Now Print all the values - so we can use it for testing with tools like soapui */
            Console.WriteLine(string.Format("nonce: {0}", nonce));
            Console.WriteLine(string.Format("password digest: {0}", passwordDigest));
            Console.WriteLine(string.Format("encoded nonce: {0}", encodedNonce));
            Console.WriteLine(string.Format("creation date: {0}", creationDate));
        }
    }
}

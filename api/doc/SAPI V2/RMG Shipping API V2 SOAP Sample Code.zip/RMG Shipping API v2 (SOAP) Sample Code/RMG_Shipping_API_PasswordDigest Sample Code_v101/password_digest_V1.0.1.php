#!/usr/bin/php
<?php
/*---------------------------------------------------------------------------------*/
/* This code has been written as a sample to demonstrate how the password digest   */
/* can be calculated, to populate the WS-security header of the SAPI SOAP service. */
/* The security header for the SAPI service needs to provide,                      */
/*  Username as - <wsse:Username>YOURUSENAME</wsse:Username>                       */
/*                 where YOURUSENAME is the username provided by RMG               */
/*  Password as - <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest">PASSWORDDIGEST</wsse:Password> */
/*                where PASSWORDDIGEST is calculated as shown in the code below    */
/*  Nonce as - <wsse:Nonce EncodingType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary">ENCODEDNONCE</wsse:Nonce>   */
/*                where ENCODEDNONCE is shown in the code below                    */
/* Creation date - <wsu:Created>CREATIONDATE</wsu:Created>                         */
/*                where CREATIONDATE is shown in the code below                    */
/*                                                                                 */
/*To Use code below, one must a) Change the password to your password              */
/*                                                                                 */
/*                                                                                 */
/*                                                                                 */
/*       Author:    RMG                                                            */
/*       Version:   1.0.1                                                          */
/*       Date:      19/04/2016                                                     */
/*                                                                                 */
/*                                                                                 */
/*                                                                                 */
/*                                                                                 */
/*---------------------------------------------------------------------------------*/

	/* The value below should be changed to your password.  If you store the password  */  
	/* as hashed in your database, you will need to change the code below to remove hashing */

		$password = 'Password1*';

	/* CREATIONDATE - The timestamp. The computer must be on correct time or the server you are
	 * connecting may reject the password digest for security.
	 */
        $creationDate = gmdate('Y-m-d\TH:i:s\Z');
		
	/* NONCE - A random word. 
	 * The use of rand() may repeat the word if the server is very loaded.
	 */
        $nonce = mt_rand();

	/* PASSWORDDIGEST This is the way to create the password digest. As per OASIS standard
	 * digest = base64_encode(Sha1(nonce + creationdate + Sha1(password)))
	 * Note that we use a Sha1(password) instead of the plain password above
	 */
		$nonce_date_pwd = $nonce.$creationDate.base64_encode(sha1($password, TRUE));
        $passwordDigest = base64_encode(sha1($nonce_date_pwd, TRUE));
						
	/* ENCODEDNONCE - Now encode the nonce for security header */
        $encodedNonce = base64_encode($nonce);
		
	/* Now Print all the values - so we can use it for testing with tools like soapui */
		echo 'nonce: ' . $nonce . PHP_EOL;
		echo 'password digest: ' . $passwordDigest . PHP_EOL;
		echo 'encoded nonce: ' . $encodedNonce . PHP_EOL;
		echo 'creation date: ' . $creationDate . PHP_EOL;
?>
//---------------------------------------------------------------------------------*/
// This code has been written as a sample to demonstrate how the password digest   */
// can be calculated, to populate the WS-security header of the SAPI SOAP service. */
//                                                                                 */
// This code is designed for Java 7 and uses standard libraries only;              */
// it also suggests alternatives for the random string and encoding functions      */
// that are simpler, but which require external libraries or Java 8.               */
//                                                                                 */
// The security header for the SAPI service needs to provide,                      */
//  Username as - <wsse:Username>YOURUSENAME</wsse:Username>                       */
//                 where YOURUSENAME is the username provided by RMG               */
//  Password as - <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest">PASSWORDDIGEST</wsse:Password> */
//               where PASSWORDDIGEST is calculated as shown in the code below    */
//  Nonce as  - <wsse:Nonce EncodingType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary">ENCODEDNONCE</wsse:Nonce>   */
//                where ENCODEDNONCE is shown in the code below                    */
// Creation date - <wsu:Created>CREATIONDATE</wsu:Created>                         */
//                where CREATIONDATE is shown in the code below                    */
//                                                                                 */
//To Use code below, one must a) Change the password to your password              */
//                                                                                 */
//                                                                                 */
//                                                                                 */
//       Author:    RMG                                                            */
//       Version:   1.0.1                                                          */
//       Date:      19/04/2016                                                     */
//                                                                                 */
//                                                                                 */
//                                                                                 */
//                                                                                 */
//---------------------------------------------------------------------------------*/
import java.util.Date;
import java.util.Random;
import java.util.TimeZone;
import java.text.SimpleDateFormat;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import sun.misc.BASE64Encoder; 
	// alternatively use an external library e.g. org.apache.commons.codec.binary.Base64 or in Java 8 use java.util.Base64

public class PasswordDigest   
{

	// The value below should be changed to your password.  If you store the password  */
    // as hashed in your database, you will need to change the code below to remove hashing */
    private static final String password = "DummyPassword*";
    private MessageDigest messageDigest;
    private BASE64Encoder encoder;
    
    public static void main(String[] args) throws Exception {
       new PasswordDigest().generatePasswordDigest();
    }

    public PasswordDigest() throws NoSuchAlgorithmException{
        messageDigest = MessageDigest.getInstance("SHA-1");
        encoder = new BASE64Encoder();
	}
    
    private void generatePasswordDigest() throws Exception {
        // CREATIONDATE - The timestamp. The computer must be on correct time or the server you are
        // connecting may reject the password digest for security. The format below works for Java 7 and above
    	SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX");
    	dateFormatter.setTimeZone(TimeZone.getTimeZone("UTC"));
        String creationDate = dateFormatter.format(new Date());
               
        // declare a nonce (number used once) and assign it a random string.
        // alternatively use an external library e.g.
        //     org.apache.commons.lang.RandomStringUtils.random(20);
        byte[] nonceBytes = new byte[15];
        new Random().nextBytes(nonceBytes);
        String nonce = encoder.encode(nonceBytes);
        
        // PASSWORDDIGEST This is the way to create the password digest. As per OASIS standard
        // digest = base64_encode(Sha1(nonce + creationdate + Sha1(password)))
        // Note that we use a Sha1(password) instead of the plain password above
        String encodedPassword = encoder.encode(messageDigest.digest(password.getBytes("UTF-8")));
        String nonceDataPassword = nonce + creationDate + encodedPassword;
        String passwordDigest = encoder.encode(messageDigest.digest(nonceDataPassword.getBytes("UTF-8")));
       
        // ENCODEDNONCE - Now encode the nonce for security header */
        String encodedNonce = encoder.encode(nonce.getBytes("UTF-8"));
        
        // Now Print all the values - so we can use it for testing with tools like soapui */
        System.out.println("nonce: " + nonce);
        System.out.println("password digest: " + passwordDigest);
        System.out.println("encoded nonce: " + encodedNonce);
        System.out.println("creation date: " + creationDate);
    }
}



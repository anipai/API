##---------------------------------------------------------------------------------*/
## This code has been written as a sample to demonstrate how the password digest   */
## can be calculated, to populate the WS-security header of the SAPI SOAP service. */
## The security header for the SAPI service needs to provide,                      */
##  Username as - <wsse:Username>YOURUSENAME</wsse:Username>                       */
##                 where YOURUSENAME is the username provided by RMG               */
##  Password as - <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest">PASSWORDDIGEST</wsse:Password> */
##                where PASSWORDDIGEST is calculated as shown in the code below    */
##  Nonce as - <wsse:Nonce EncodingType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary">ENCODEDNONCE</wsse:Nonce>   */
##                where ENCODEDNONCE is shown in the code below
## Creation date - <wsu:Created>CREATIONDATE</wsu:Created>                         */
##                where CREATIONDATE is shown in the code below                    */
##                                                                                 */
##To Use code below, one must a) Change the password to your password              */
##                                                                                 */
##                                                                                 */
##                                                                                 */
##       Author:    RMG                                                            */
##       Version:   1.0.1                                                          */
##       Date:      19/04/2016                                                     */
##                                                                                 */
##                                                                                 */
##                                                                                 */
##                                                                                 */
##---------------------------------------------------------------------------------*/
#!/usr/bin/perl
#
use strict;
use warnings;
use POSIX qw(strftime);
#
use MIME::Base64 qw(encode_base64 decode_base64);
use Digest::SHA1 qw(sha1_base64);

##-------------------------------------------------------------------------------------
## The value below should be changed to your password.  If you store the password  */  
## as hashed in your database, you will need to change the code below to remove hashing */
my $password = "DummyPassword*";

##-------------------------------------------------------------------------------------
##  NONCE - A random word. The use of rand() may repeat the word if the server is very loaded.
##
my $nonce = int(rand(999999)); #"Seed string for NONCE - A random word";

##-------------------------------------------------------------------------------------
## CREATIONDATE - The timestamp. The computer must be on correct time or the server you are
##                connecting may reject the password digest for security.
##
my $creationDate = strftime "%Y-%m-%dT%H:%M:%SZ", localtime;

##--------------------------------------------------------------------------------
#
##   PASSWORDDIGEST This is the way to create the password digest. As per OASIS standard
##                  digest = base64_encode(Sha1(nonce + creationdate + Sha1(password)))
##                  Note that we use a Sha1(password) instead of the plain password above
##   Concatenate the nonce+creationdate+hashed_password
##
my $conct = $nonce . $creationDate . sha1_base64($password)."=";
my $passwordDigest = sha1_base64($conct)."=";

##--------------------------------------------------------------------------------------
##  Print the values, in case we want to test using SOAPUI
##
print "nonce: " . $nonce . "\n";
print "password digest: " . $passwordDigest. "\n";
print "encoded nonce: " . encode_base64($nonce);
print "creation date: " . $creationDate. "\n";




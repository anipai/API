
The sample code provided in this folder is intended to accelerate customer integration with Royal Mail's Shipping API. The sample code assists with the population of the WS-Security element in the SOAP request message in line with the security information provided in the Shipping API Technical User Guide. The username and password required to call the API are separately supplied by Royal Mail as part of the customer onboarding process.  

Please rename the .ex file to .exe to make it an executable file.

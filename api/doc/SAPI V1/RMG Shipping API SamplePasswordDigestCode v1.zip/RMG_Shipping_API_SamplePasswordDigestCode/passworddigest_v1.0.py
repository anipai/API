#!/usr/local/bin/python2.7
import os
import sha
import binascii
import base64
import time
import random
# ---------------------------------------------------------------------------------*/
#  This code has been written as a sample to demonstrate how the password digest   */
#  can be calculated, to populate the WS-security header of the SAPI SOAP service. */
#  The security header for the SAPI service needs to provide,                      */
#   Username as - <wsse:Username>YOURUSENAME</wsse:Username>                      */
#                  where YOURUSENAME is the username provided by RMG               */
#   Password as - <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest">PASSWORDDIGEST</wsse:Password> */
#                 where PASSWORDDIGEST is calculated as shown in the code below    */
#   Nonce as - <wsse:Nonce EncodingType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary">ENCODEDNONCE</wsse:Nonce>   */
#                 where ENCODEDNONCE is shown in the code below
#  Creation date - <wsu:Created>CREATIONDATE</wsu:Created>                         */
#                 where CREATIONDATE is shown in the code below                   */

# To Use code below, one must a) Change the password to your password             */
#                                                                                 */
#                                                                                 */
#                                                                                 */
#        Author:    RMG                                                           */
#        Version:   1.0                                                           */
#        Date:      08/10/2014                                                    */
#                                                                                 */
#                                                                                 */
#                                                                                 */
#                                                                                 */
# --------------------------------------------------------------------------------*/

#  The value below should be changed to your password.  If you store the password  */  
#  as hashed in your database, you will need to change the code below to remove hashing */
#----------------------------------------------------------------------------
password = 'xxxxxx*'
#--------------------------------------------------------------------
#  CREATIONDATE - The timestamp. The computer must be on correct time
#  or the server you are connecting may reject the password digest
#  for security.
#------------------------------------------------------------------------
CREATIONDATE =  time.strftime('%Y-%m-%dT%H:%M:%SZ', time.localtime(time.time()))
#---------------------------------------------------------------------
#  NONCE - A random word. The use of rand() may repeat the word if the 
#  server is very loaded.
#----------------------------------------------------------------------------
nonce =  str(random.randint(0,9999999999))
#--------------------------------------------------------------------------
#  PASSWORDDIGEST This is the way to create the password digest. 
#   As per OASIS standard
#        digest = base64_encode(Sha1(nonce + creationdate + password)
#       however note that we use a SHA1(password) instead of the password above
#--------------------------------------------------------------------------
hashedpassword = sha.new(password).digest()
digest = sha.new(nonce + CREATIONDATE + hashedpassword).digest()
PASSWORDDIGEST = base64.b64encode(digest)
#-----------------------------------------------------------------------
#  ENCODEDNONCE - Now encode the nonce for security header */
ENCODEDNONCE = base64.b64encode(nonce)
#----------------------------------------------------------------------
# Now Print all the values - so we can use it for testing with 
# tools like soapuiuse 
#---------------------------------------------------------------------   
print 'WS Security Header elements'
print '---------------------------'
print 'Nonce = ', nonce
print 'PASSWORDDIGEST= ', PASSWORDDIGEST
print 'ENCODEDNONCE= ', ENCODEDNONCE
print 'CREATIONDATE= ', CREATIONDATE
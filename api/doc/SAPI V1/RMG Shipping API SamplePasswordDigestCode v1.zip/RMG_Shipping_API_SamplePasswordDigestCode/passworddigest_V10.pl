##---------------------------------------------------------------------------------*/
## This code has been written as a sample to demonstrate how the password digest   */
## can be calculated, to populate the WS-security header of the SAPI SOAP service. */
## The security header for the SAPI service needs to provide,                      */
##  Username as - <wsse:Username>YOURUSENAME</wsse:Username>                      */
##                 where YOURUSENAME is the username provided by RMG               */
##  Password as - <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest">PASSWORDDIGEST</wsse:Password> */
##                where PASSWORDDIGEST is calculated as shown in the code below    */
##  Nonce as - <wsse:Nonce EncodingType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary">ENCODEDNONCE</wsse:Nonce>   */
##                where ENCODEDNONCE is shown in the code below
## Creation date - <wsu:Created>CREATIONDATE</wsu:Created>                         */
##                where CREATIONDATE is shown in the code below                   */

##To Use code below, one must a) Change the password to your password             */
##                                                                                */
##                                                                                */
##                                                                                */
##       Author:    RMG                                                           */
##       Version:   1.0                                                           */
##       Date:      08/10/2014                                                    */
##                                                                                */
##                                                                                */
##                                                                                */
##                                                                                */
##--------------------------------------------------------------------------------*/
#!/usr/bin/perl
#
use strict;
use warnings;
use POSIX qw(strftime);
#
use MIME::Base64 qw(encode_base64 decode_base64);
use Digest::SHA1 qw(sha1);
##-------------------------------------------------------------------------------------
##  NONCE - A random word. The use of rand() may repeat the word if the server is
##          very loaded.
##
#
my $nonce = int(rand(999999)); #"Hi Neopost";
##-------------------------------------------------------------------------------------
## CREATIONDATE - The timestamp. The computer must be on correct time or the server you are
##                connecting may reject the password digest for security.
##

my $creationdate = strftime "%Y-%m-%dT%H:%M:%SZ", localtime;

## The value below should be changed to your password.  If you store the password  */  
## as hashed in your database, you will need to change the code below to remove hashing */

my $password = "Password1*";
##--------------------------------------------------------------------------------
#
##   PASSWORDDIGEST This is the way to create the password digest. As per OASIS standard
##                  digest = base64_encode(Sha1(nonce + creationdate + password)
##                  however note that we use a SHA1(password) instead of the password above
##   Concatenate the nonce+creationdate+hashed_password
##
my $conct = $nonce . $creationdate . (sha1($password));
my $passworddigest = encode_base64(sha1($conct));
##--------------------------------------------------------------------------------------
##  Print the values, in case we want to test using SOAPUI
##
print "Nonce:                       " . $nonce;
print "\n";
print "Password Digest:             " . $passworddigest;
print "\n";
print "Encoded Nonce:               " . encode_base64($nonce);
print "\n";
print "Creation date:               " . $creationdate;
print "\n";


